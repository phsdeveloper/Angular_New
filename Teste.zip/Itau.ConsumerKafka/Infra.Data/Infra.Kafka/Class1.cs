﻿namespace Infra.Kafka;
public class Class1
{

}

