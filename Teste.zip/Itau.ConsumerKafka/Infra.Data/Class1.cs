﻿namespace Infra.Data;
public class Class1
{

}

