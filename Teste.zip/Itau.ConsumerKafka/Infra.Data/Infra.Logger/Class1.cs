﻿namespace Infra.Logger;
public class Class1
{

}

